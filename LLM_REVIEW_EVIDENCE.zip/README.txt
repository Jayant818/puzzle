MrBeast $10,000 puzzle — compact evidence bundle
Generated 2026-09-07 from /home/jayant/Desktop/mrbeast-challenge

LLM_REVIEW_PACKET.md   The self-contained dossier. Start here. A .docx and .pdf
                       version with the same content and embedded images exists
                       alongside this ZIP in the original workspace.

dossier_images/        Twelve clue images referenced by the dossier.

tools/                 Nine Python scripts. All of them assert their own claims.
                       solve_desk.py needs data/work_audubon_plate_concordance.html
                       and data/work_yt_owl14_gateway.en.vtt at their original
                       relative paths (work/audubon/, work/yt/) to run unmodified.

data/                  Small source and result files, renamed with their original
                       path baked into the filename (slashes became underscores):
                         work_yt_blue_251634_audit_results.json  148 bounded 251634 models
                         work_yt_blue_alternative_results.json   2,408 rail-fence configs + six-channel tests
                         work_yt_blue_key_text_tests.json        81,781 caption tests, 0 matches
                         work_video_audit_mask_counts.json       the 15-asterisk count
                         work_yt_owl14_gateway.en.vtt            gateway captions (last word FOURTH, ninth UPLOAD)
                         work_audubon_havell_plates_pitt.json    all 435 Audubon Havell plate names
                         work_audubon_plate_concordance.html     title / modern name / historical binomial
                         work_twitch_thursday.txt                Whisper transcript of the author's stream
                         work_site_rules.html                    official contest rules as fetched
                         work_yt_channel_fourths.tsv             473-entry channel snapshot
                         work_yt_main_shorts_sep6.tsv            398-entry Shorts snapshot

NOT INCLUDED: ~6 GB of video, audio, 4K frames and CyberChef builds. Section 14.4
of the dossier lists every omitted item, its size, and how to re-obtain it.
